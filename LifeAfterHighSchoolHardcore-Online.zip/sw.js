const CACHE='life-after-high-school-v1';
const APP=['./','./index.html','./manifest.webmanifest'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(x=>{if(x.ok && new URL(e.request.url).origin===location.origin){const y=x.clone();caches.open(CACHE).then(c=>c.put(e.request,y));}return x;}).catch(()=>caches.match('./index.html'))));});
